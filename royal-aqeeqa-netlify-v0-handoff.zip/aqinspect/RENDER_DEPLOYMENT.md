# Deploy Royal Aqeeqa Invitation on Render

This project is a single Node.js/Express web service with a Vite-built React frontend and SQLite database.

## Render Web Service settings
- Runtime: Node
- Build command: `npm install && npm run build`
- Start command: `npm start`
- Health check path: `/`
- Node version: `22.22.0` (also pinned in `.node-version`)

## Persistent disk (required for data retention)
Attach a persistent disk to the web service:
- Mount path: `/var/data`
- Size: choose a plan that supports persistent disks (Render Free web services do not support them)

Set environment variable:
- `DATA_DIR` = `/var/data`

On the first start, the app copies the bundled `data/wedding.db` into `/var/data/wedding.db` if no persistent database exists yet. All subsequent SQLite changes and uploaded media are stored on the disk.

Do not delete or replace `/var/data/wedding.db` after the first deployment. Back it up before any migration.

## Admin security
The bundled database already contains an administrator account. Log in using the administrator email/password you used in the original app, then change the password in the admin settings. Do not rely on the fallback credentials for a production site.

## Important
Do not deploy this service as a Static Site. It must be a Web Service because it runs `server.ts` and handles `/api/*` requests, SQLite, uploads, admin login, and RSVPs.
