# v0 migration prompt — Royal Aqeeqa Invitation

Import this repository into v0 and treat the existing source code as the source of truth. Do not redesign or remove working features unless required for the migration.

## Goal
Convert this existing React + TypeScript + Vite + Express + SQLite application into a production-ready Next.js App Router application that can be deployed on Netlify (or Vercel) with a persistent managed backend.

## Preserve the existing product
- Royal Aqeeqa invitation visual design, typography, colors, animations, transitions, ornamentation and responsive behavior.
- Envelope/cover opening interaction, scratch reveal, countdown, event timeline, photo gallery, venue/map card, ambient background and audio controls.
- Public default invitation and public invitation-by-slug routes.
- RSVP submission and guest wishes.
- Admin login/logout, credential update, invitation list, create/edit/publish/set-default/delete, media uploader, and RSVP management.
- Existing bundled images/audio and all invitation content in `data/wedding.db`.

## Required architecture migration
1. Replace Vite entry/build with Next.js App Router while preserving component behavior and styling. Keep interactive components as client components only where needed.
2. Remove runtime dependence on `server.ts`, Express, `node:sqlite`, local filesystem writes and Multer from deployed serverless routes.
3. Migrate SQLite records from `data/wedding.db` into Supabase Postgres. Inspect the actual SQLite schema and rows first; create a migration script that preserves IDs, invitation slug, publication/default flags, admin records where safely migratable, RSVP records, media metadata and timestamps. Never silently discard rows.
4. Use Supabase Auth for admin authentication. Do not expose service-role keys in browser code. Use server-only environment variables and server-side authorization checks.
5. Use Supabase Storage buckets for uploaded image, audio and video files. Preserve existing bundled media; migrate existing uploaded media if any. Use secure upload policies, file type checks and sensible size limits.
6. Implement server-side route handlers/server actions for public invitation reads, RSVP submissions, admin CRUD, publish/default operations, credential management and media upload. Validate all input on the server.
7. Configure Row Level Security: public users may read only published invitations and submit RSVP records; only authenticated authorized admins may manage invitations, media and RSVP data. Never make admin tables publicly readable.
8. Keep public routes stable: `/` for the published default invitation and `/i/[slug]` for a specific published invitation. Keep an admin route such as `/admin`.
9. Add robust loading, empty, unpublished, not-found and API error states. Avoid showing “Invitation Not Found” when the backend is simply unconfigured; show a clear setup error instead.
10. Add `.env.example` documenting `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and server-only `SUPABASE_SERVICE_ROLE_KEY` (only if genuinely needed). Do not put real credentials in the repo.
11. Add Netlify configuration compatible with the selected Next.js adapter/runtime, and document build/deploy steps. Ensure dynamic routes and server handlers actually work on Netlify; do not deploy as a static export if API functionality is required.

## Data migration and safety requirements
- First inspect and report the SQLite schema, row counts, existing published slug(s), admin accounts, RSVP counts and media references.
- Provide an idempotent migration script and a dry-run mode.
- Do not overwrite an existing Supabase database without explicit approval.
- Preserve a backup of `data/wedding.db`; do not delete it.
- Do not print or expose password hashes, session tokens, API keys or secrets.
- If password hashes cannot be securely migrated to Supabase Auth, explain the reset/invite flow and require a secure admin password reset rather than weakening authentication.
- Check whether `data/uploads` contains files and report missing media references.

## Acceptance tests
- Main published invitation loads without login.
- `/i/syed-aakif-aqeeqa-mubarak` loads the correct invitation if that slug is still published in the source database.
- Countdown, gallery, music selection/playback, venue links and all visual interactions work on mobile and desktop.
- RSVP submission persists and appears in admin.
- Admin login is secure; unauthorized visitors cannot access admin APIs.
- Admin can create, edit, preview, publish and unpublish invitations.
- Media upload persists in Supabase Storage and its URL remains valid after redeploy.
- No API call is accidentally rewritten to `index.html`.
- Build and type-check pass.

## Workflow
Work in small phases: (A) audit and architecture plan, (B) database/storage migration design, (C) Next.js conversion, (D) backend/auth implementation, (E) Netlify deployment configuration, (F) test and migration instructions. Before making destructive database changes, stop and ask for approval. Do not claim production-ready until the acceptance tests pass.
