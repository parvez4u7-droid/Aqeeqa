# Royal Aqeeqa — Netlify / v0 preparation

Start here: read `NETLIFY_V0_GUIDE.md`.

- `netlify.toml`: Vite frontend build configuration (frontend preview only until backend migration).
- `V0_MIGRATION_PROMPT.md`: full migration brief for converting this app to Next.js + Supabase while preserving features and data.
- `data/wedding.db`: original SQLite database; keep private and retain as migration source/backup.
