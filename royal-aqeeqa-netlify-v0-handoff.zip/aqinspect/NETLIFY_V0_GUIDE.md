# Netlify + v0 handoff guide

## What this package is
This archive contains the original Royal Aqeeqa application source, bundled media and SQLite database, plus a Netlify Vite frontend configuration and a detailed v0 migration prompt.

## Important architecture limitation
The current app is NOT a static-only website. It depends on an Express server (`server.ts`), SQLite (`node:sqlite`), local disk uploads (`data/uploads`), admin sessions, RSVP writes and `/api/*` endpoints. Netlify's static deploy cannot run that Express server or persist SQLite/local uploads. The included `netlify.toml` can build and publish the Vite frontend, but the dynamic features will not work until the backend is migrated or hosted separately.

## Recommended path for a fully functional Netlify deployment
1. Keep this repository private because it contains a database with administrator and invitation records.
2. Import the repository into v0 using its GitHub import workflow.
3. Open `V0_MIGRATION_PROMPT.md` and give its full contents to v0. Ask v0 to audit first, then migrate the app to Next.js + Supabase Postgres + Supabase Storage + secure server-side auth.
4. Do not let v0 discard `data/wedding.db`. Require an idempotent migration script and a backup.
5. Create a Supabase project and configure its URL/anon key and server-only service role key as environment variables in the hosting platform. Never commit secrets.
6. Deploy the converted Next.js application to Netlify using the current supported Next.js runtime/adapter. Do not use static export if admin/API functionality is required.
7. Test public invitation, slug route, RSVP, admin login, CRUD, publishing and media uploads before sharing the URL.

## Frontend-only preview on Netlify (not production)
For a visual preview only, connect this repo to Netlify and use:
- Build command: `npm run build`
- Publish directory: `dist`
- Node version: `22.22.0`

This preview is not a working full application: API-backed invitation retrieval, login, admin actions, RSVPs and uploads require the backend migration described above.

## v0
Use the GitHub repository import option in v0, then paste the contents of `V0_MIGRATION_PROMPT.md`. v0 should work from the source repository; this archive is not itself a deployable v0 project until v0 completes the requested framework/backend migration.
